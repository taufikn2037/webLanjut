<!DOCTYPE html>
<html>
	<head>
		<title>Praktikum Web</title>
	</head>
	<body>
		<h1>Saya Siapa?</h1>
	</body>
</html>